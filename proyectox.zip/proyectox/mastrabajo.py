from flask import Flask, render_template, request
app = Flask(__name__)
#@app.route("/")
#def index():
#	return "<p><b>Hello, World!!!</b></p>"
#@app.route("/<string:name>")
#def makako(name):
#	return "<p><b>Hello, {}!!!</b></p>".format(name)
@app.route("/")
def index():
	return render_template("main.html")
@app.route("/CV", methods=["POST"])
def CV():
	name=request.form.get("name")
	date=request.form.get("fecha")
	occupation=request.form.get("ocupacion")
	email=request.form.get("email")
	phone=request.form.get("phone")
	nationality=request.form.get("nationality")
	ilevel=request.form.get("ilevel")
    #flevel=request.form.get("flevel")
    #pro=request.form.get("pro")
	skill=request.form.get("skill")
	ability=request.form.get("ability")
    #profile=request.form.get("profilel")
    
	return render_template("CV.html",
        newname=name,
		newdate=date,
        newoccupation=occupation,
        newcel=phone,
        newemail=email,
        newnationality=nationality,
        newilevel=ilevel,
        #newflevel=flevel,
        newskill=skill,
        newability=ability)
        #newpro=pro,
        #newprofile=profile)
