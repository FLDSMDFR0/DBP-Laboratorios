document.addEventListener('DOMContentLoaded', () => {
	
	var incognito = document.getElementById('incognito')
	var ability1 = document.getElementById('a1');
	var ability2 = document.getElementById('a2');
	var ability3 = document.getElementById('a3');
	var ability4 = document.getElementById('a4');
	var ability5 = document.getElementById('a5');
	var ability6 = document.getElementById('a6');
	var ability7 = document.getElementById('a7');
	var abilities = [];
	var abi_state,level_state= false;
	var englishlvl = document.getElementsByName('ilevel');
	document.addEventListener('click', function()
	{
		abilities = [];
		for (var i = 0;i < 4; i++)
		{
			if (englishlvl[i].checked == true)
				level_state=true;
		}
		if (ability1.checked == true)
			abilities.push(ability1.value);
		if (ability2.checked == true)
			abilities.push(ability2.value);
		if (ability3.checked == true)
			abilities.push(ability3.value);
		if (ability4.checked == true)
			abilities.push(ability4.value);
		if (ability5.checked == true)
			abilities.push(ability5.value);
		if (ability6.checked == true)
			abilities.push(ability6.value);
		if (ability7.checked == true)
			abilities.push(ability7.value);
		//console.log(abilities);
		incognito.setAttribute('value', abilities);
		if (abilities[0])
			abi_state = true;
		else
			abi_state = false;
	})
	var control01,control02,control04,control05 = false;
	document.querySelector('#submit');
	//console.log(document.querySelector('#name'));
	document.querySelector('#submit').disabled = true;
	document.querySelector('#name').onkeyup = () => {
		if (document.querySelector('#name').value.length > 0)
			control01 = true;
			//console.log(":v");
	}
	document.querySelector('#occupation').onkeyup = () => {
		if (document.querySelector('#occupation').value.length > 0)
			control02 = true;
			//console.log(":v");
	}
	document.querySelector('#Skills').onkeyup = () => {
		if (document.querySelector('#Skills').value.length > 0)
			control04 = true;
			//console.log("-_-");
	}
	document.querySelector('#profile').onkeyup = () => {
		if (document.querySelector('#profile').value.length > 0)
			control05 = true;
			//console.log("-_-");
	}
	document.addEventListener('click', function()
	{
		if (control01 == true & control02 == true & control04 == true & abi_state == true & level_state == true & control05 == true)
			//console.log("e_e");
			document.querySelector('#submit').disabled = false;
		else 
			//console.log("e_e");
			document.querySelector('#submit').disabled = true;
	})
});