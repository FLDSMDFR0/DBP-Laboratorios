#parent {
      display: flex;
      font-family: sans-serif;
    }
    #sect_1 {
      width: 200px;
      padding: 30px 0px 30px 40px;
      background: #585858;
    }
    #sect_2 {
      width: 380px;
      padding: 30px 100px 30px 0px;
      background: #585858;
      font-family: Trebuchet MS;
    }
    #sect_3 {
      width: 200px;
      padding: 30px;
      background: #f2f3f3;
    }
    #sect_4 {
      width: 400px;
      padding: 30px;
      background: #fffefe;
    }